import * as S from "./style"
import logo from "../../assets/compass-logo.png"
import { Outlet } from "react-router-dom"

export const Home = () => {
    return (
        <S.Page>
        <S.textContainer>
        <S.title>Welcome,</S.title>
          
          <Outlet />
        </S.textContainer>
        <S.imageContainer>
          <S.background>
            <S.logo src={logo} />
          </S.background>
        </S.imageContainer>
      </S.Page>
    )
}